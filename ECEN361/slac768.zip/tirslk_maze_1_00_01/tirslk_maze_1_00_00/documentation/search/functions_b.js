var searchData=
[
  ['reflectance_5fcenter',['Reflectance_Center',['../_reflectance_8h.html#aa22dec68ae7198f36322850ac7a422ff',1,'Reflectance.c']]],
  ['reflectance_5fend',['Reflectance_End',['../_reflectance_8h.html#af0b599174bf91c1b0199f95037ca78be',1,'Reflectance.c']]],
  ['reflectance_5finit',['Reflectance_Init',['../_reflectance_8h.html#a7e72a241dafb5d6f84cfd44f5a02aaef',1,'Reflectance.c']]],
  ['reflectance_5fposition',['Reflectance_Position',['../_reflectance_8h.html#a77217ca37755bfbc38ec0eaaf4e7c49a',1,'Reflectance.c']]],
  ['reflectance_5fread',['Reflectance_Read',['../_reflectance_8h.html#a139f16024daa08baa1cdfa00bb0c3fa8',1,'Reflectance.c']]],
  ['reflectance_5fstart',['Reflectance_Start',['../_reflectance_8h.html#a5c1cd82fe48fdf60b8ac1bcfd34cb0d0',1,'Reflectance.c']]],
  ['rightconvert',['RightConvert',['../_i_r_distance_8h.html#a9ab277a755dc326cb269ff7855bc4f9f',1,'IRDistance.c']]],
  ['rxfifo0_5fget',['RxFifo0_Get',['../_f_i_f_o0_8h.html#ac7c45c957c34358649129833a8e4944a',1,'FIFO0.c']]],
  ['rxfifo0_5finit',['RxFifo0_Init',['../_f_i_f_o0_8h.html#a06eb53f9cade465c55296709e95d4114',1,'FIFO0.c']]],
  ['rxfifo0_5fput',['RxFifo0_Put',['../_f_i_f_o0_8h.html#a92f3417eb801d56616b076240d69a1b3',1,'FIFO0.c']]],
  ['rxfifo0_5fsize',['RxFifo0_Size',['../_f_i_f_o0_8h.html#a5df480c504a961365182a947dff8b868',1,'FIFO0.c']]]
];
