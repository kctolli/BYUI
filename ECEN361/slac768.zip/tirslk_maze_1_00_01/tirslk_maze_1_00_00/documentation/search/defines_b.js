var searchData=
[
  ['scoreboardsize',['SCOREBOARDSIZE',['../_scoreboard_8h.html#a3d5d9682daa98b10df2206db1111b2fc',1,'Scoreboard.h']]],
  ['setmrdy',['SetMRDY',['../_g_p_i_o_8h.html#a360fc047a56e59fddb8f60da16d4dcd7',1,'GPIO.h']]],
  ['setreset',['SetReset',['../_g_p_i_o_8h.html#ae92a6c3bd3d92adffd14d58a43f8b3b4',1,'GPIO.h']]],
  ['sof',['SOF',['../_a_p_8h.html#a1a8a99dbd3696baa83bd6635d37b129a',1,'AP.h']]],
  ['sp',['SP',['../_e_u_s_c_i_a0_8h.html#aecd69d9a67487cc45c38eb184c50538a',1,'SP():&#160;EUSCIA0.h'],['../_u_a_r_t0_8h.html#aecd69d9a67487cc45c38eb184c50538a',1,'SP():&#160;UART0.h'],['../_u_a_r_t1_8h.html#aecd69d9a67487cc45c38eb184c50538a',1,'SP():&#160;UART1.h']]]
];
