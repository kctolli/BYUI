var searchData=
[
  ['notifycharacteristics',['NotifyCharacteristics',['../struct_notify_characteristics.html',1,'']]]
];
