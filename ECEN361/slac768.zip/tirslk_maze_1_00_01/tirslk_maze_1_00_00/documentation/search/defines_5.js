var searchData=
[
  ['fifofail',['FIFOFAIL',['../_f_i_f_o0_8h.html#a5e32948644a47e4f3ce03dbfd93fbcaa',1,'FIFO0.h']]],
  ['fifosuccess',['FIFOSUCCESS',['../_f_i_f_o0_8h.html#ae68463d3e90d2f00b15c73bdb92bb0f7',1,'FIFO0.h']]]
];
