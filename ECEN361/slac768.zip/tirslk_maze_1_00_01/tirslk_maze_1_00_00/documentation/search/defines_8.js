var searchData=
[
  ['max_5fx',['MAX_X',['../_nokia5110_8h.html#a898606140dee9ce0adf096de00824d94',1,'Nokia5110.h']]],
  ['max_5fy',['MAX_Y',['../_nokia5110_8h.html#a985cc18be96dda7f59fd0400725e4aef',1,'Nokia5110.h']]]
];
