var searchData=
[
  ['tx0fifosize',['TX0FIFOSIZE',['../_f_i_f_o0_8h.html#abdf785e04495ffe30f316ac526bcae12',1,'FIFO0.h']]]
];
