var searchData=
[
  ['scoreboardelement',['ScoreboardElement',['../struct_scoreboard_element.html',1,'']]],
  ['state',['State',['../struct_state.html',1,'']]]
];
