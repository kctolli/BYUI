var structcharacteristics =
[
    [ "callBackRead", "structcharacteristics.html#a33bc0b4eedb2b08c3d6f53f44756a054", null ],
    [ "callBackWrite", "structcharacteristics.html#a6cf2fd02f740bb22a21862fd9dc02a6b", null ],
    [ "pt", "structcharacteristics.html#a757dc8b50cebbb66b1727de65efb1d87", null ],
    [ "size", "structcharacteristics.html#aaba88b24a21a6c70c895c0d55f4a69a0", null ],
    [ "theHandle", "structcharacteristics.html#aa450ab8b60a7c34d68070c5991b60d05", null ]
];