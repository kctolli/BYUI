var _cortex_m_8h =
[
    [ "DisableInterrupts", "_cortex_m_8h.html#ac866dbaf7b167e5c46bb33de42eee84d", null ],
    [ "EnableInterrupts", "_cortex_m_8h.html#ab712356331a62b04aebcb373865e68c4", null ],
    [ "EndCritical", "_cortex_m_8h.html#a670da3ff1aea0c7d54c40e9e40b5eeed", null ],
    [ "StartCritical", "_cortex_m_8h.html#a6e7e2088607214bc15b17ac57b57df1b", null ],
    [ "WaitForInterrupt", "_cortex_m_8h.html#a80ae22f2f73496246542c428c4bec38f", null ]
];