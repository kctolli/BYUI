var _timer32_8h =
[
    [ "timer32divider", "_timer32_8h.html#afdb0398556993e7d1372ed0530d2b6e4", [
      [ "T32DIV1", "_timer32_8h.html#afdb0398556993e7d1372ed0530d2b6e4ab7dfe7ec0e960f24bc0157eab07370fb", null ],
      [ "T32DIV16", "_timer32_8h.html#afdb0398556993e7d1372ed0530d2b6e4adfcc5bfe038a0d949f3d1e0f8cc41530", null ],
      [ "T32DIV256", "_timer32_8h.html#afdb0398556993e7d1372ed0530d2b6e4a2390009f4e8870f0e9f465fc4dbdefc5", null ]
    ] ],
    [ "Timer32_Init", "_timer32_8h.html#abe5295a93d00844f47a5c98dd548ffd8", null ]
];