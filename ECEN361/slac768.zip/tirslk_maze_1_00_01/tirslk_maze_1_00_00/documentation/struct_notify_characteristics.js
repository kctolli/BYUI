var struct_notify_characteristics =
[
    [ "callBackCCCD", "struct_notify_characteristics.html#a0ffcd234e119a923b0c883af0ef13fe9", null ],
    [ "CCCDhandle", "struct_notify_characteristics.html#a04a97eb06c60abd55246d8c75900be79", null ],
    [ "CCCDvalue", "struct_notify_characteristics.html#a80e24ab149b63fd9180ce2b9cc53e78e", null ],
    [ "pt", "struct_notify_characteristics.html#a757dc8b50cebbb66b1727de65efb1d87", null ],
    [ "size", "struct_notify_characteristics.html#aaba88b24a21a6c70c895c0d55f4a69a0", null ],
    [ "theHandle", "struct_notify_characteristics.html#aa450ab8b60a7c34d68070c5991b60d05", null ],
    [ "uuid", "struct_notify_characteristics.html#aaa1ded1f77a9c12a196ed4ba2ce5f95d", null ]
];