var struct_scoreboard_element =
[
    [ "first", "struct_scoreboard_element.html#a045dc0d3f00913f6fa5bbd9a23ce04fb", null ],
    [ "last", "struct_scoreboard_element.html#af73979e49cd07ebdfa2320fe32e39589", null ],
    [ "middle", "struct_scoreboard_element.html#a8fa51efb2c833b4930d49365aeacb83e", null ],
    [ "score", "struct_scoreboard_element.html#abe902382ebcf927bbba5c0d47bf53138", null ]
];