var structcommand =
[
    [ "Duration", "structcommand.html#a9f5fe90eb969acb06d00eb6ee18b213e", null ],
    [ "LeftPWM", "structcommand.html#ab44b63aba05cb8004639eeed9d9d7c62", null ],
    [ "MotorFunction", "structcommand.html#a916572fb028b2171856806121882426c", null ],
    [ "RightPWM", "structcommand.html#ad6264fce52f1e64686f26196e9b88e5d", null ]
];