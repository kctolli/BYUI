var _sys_tick_8h =
[
    [ "SysTick_Init", "_sys_tick_8h.html#aeb71ef4b996788e4aa8cda6ef617f58f", null ],
    [ "SysTick_Wait", "_sys_tick_8h.html#a8bf6781e1bcf2aac3a3a4ab5f686b972", null ],
    [ "SysTick_Wait10ms", "_sys_tick_8h.html#a812160529334c18c7be6c2cbbf450467", null ]
];