var _timer_a2_8h =
[
    [ "TimerA2_Init", "_timer_a2_8h.html#a00615bb3d3ac2fe0913e172425d33d26", null ],
    [ "TimerA2_Stop", "_timer_a2_8h.html#aaaf2b59b384355b7a7b641bd9ece7cdf", null ]
];