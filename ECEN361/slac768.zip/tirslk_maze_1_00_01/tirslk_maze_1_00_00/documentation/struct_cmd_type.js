var struct_cmd_type =
[
    [ "CmdName", "struct_cmd_type.html#a8c76e49a06a7172cd28915e22ef9d07a", null ],
    [ "fnctPt", "struct_cmd_type.html#a6232a6e73f29bc4d4c8f330a5ff9dc4f", null ],
    [ "Next", "struct_cmd_type.html#a9c1fb6e887705cb28e8f5bdfa05d25f8", null ]
];