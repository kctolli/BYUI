var _clock_8h =
[
    [ "Clock_Delay1ms", "_clock_8h.html#a975183291bc39bd04257c1458ecc4521", null ],
    [ "Clock_Delay1us", "_clock_8h.html#ac04076eda7102f291926b439cc713176", null ],
    [ "Clock_GetFreq", "_clock_8h.html#a9cba0654b940955562e7154f6b6c58f6", null ],
    [ "Clock_Init48MHz", "_clock_8h.html#a6af2755c894e5587fbc63a8a6ad084db", null ]
];