var _timer_a0_8h =
[
    [ "TimerA0_Init", "_timer_a0_8h.html#a2c8c92a1d1639005acc04276eec2acba", null ],
    [ "TimerA0_Stop", "_timer_a0_8h.html#afbe3851c1250527aa7ab549e5aa6b2df", null ]
];