var _i_r_distance_8c =
[
    [ "Ac", "_i_r_distance_8c.html#a5ab41e171aefffcb0453aa4cc21333b8", null ],
    [ "Al", "_i_r_distance_8c.html#a86ead5bf6198660292e62063b8d168eb", null ],
    [ "Ar", "_i_r_distance_8c.html#a518b61a52a9d983b1227b59ef7f31a76", null ],
    [ "Bc", "_i_r_distance_8c.html#ac09d31eac80cf9bb3e758847df703a3a", null ],
    [ "Bl", "_i_r_distance_8c.html#a4feaced0d41894d5c5b74f1a687a1cc6", null ],
    [ "Br", "_i_r_distance_8c.html#af7514765402d91e1deef9c2c9ec2ddff", null ],
    [ "Cc", "_i_r_distance_8c.html#ae2a7cf037897ea17e4ad54aae4af3002", null ],
    [ "Cl", "_i_r_distance_8c.html#a230bc3f28f7c757450eb0f7a3d30a1b9", null ],
    [ "Cr", "_i_r_distance_8c.html#ab3c7f0f0aedce722db4ce3786cff83c6", null ],
    [ "IRmaxc", "_i_r_distance_8c.html#aaf04fbcb9bc668e9c4fc2768de75e545", null ],
    [ "IRmaxl", "_i_r_distance_8c.html#a79e1f29d2557fb883b3bfeccb126817b", null ],
    [ "IRmaxr", "_i_r_distance_8c.html#ad59f028e8066c2a742387fb4c9a99624", null ],
    [ "CenterConvert", "_i_r_distance_8c.html#ad3ba9e2ae552250cfe976068777227a4", null ],
    [ "LeftConvert", "_i_r_distance_8c.html#ae2d955e3cb07ac8d706f3cfcadd2fa72", null ],
    [ "RightConvert", "_i_r_distance_8c.html#a9ab277a755dc326cb269ff7855bc4f9f", null ]
];