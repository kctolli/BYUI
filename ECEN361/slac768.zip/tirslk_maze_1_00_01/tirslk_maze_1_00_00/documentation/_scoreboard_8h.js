var _scoreboard_8h =
[
    [ "ScoreboardElement", "struct_scoreboard_element.html", "struct_scoreboard_element" ],
    [ "SCOREBOARDSIZE", "_scoreboard_8h.html#a3d5d9682daa98b10df2206db1111b2fc", null ],
    [ "SBEType", "_scoreboard_8h.html#a65b46ee1e0bd9aa6b7dce111e69c8c45", null ],
    [ "Scoreboard_Get", "_scoreboard_8h.html#aad7a6947f97c400d08be18a159c5bcd2", null ],
    [ "Scoreboard_Init", "_scoreboard_8h.html#a504c26dc8ce6eaeaa2861fb8f90c6fe0", null ],
    [ "Scoreboard_Record", "_scoreboard_8h.html#a42890fca64a257832aa702d539447ce7", null ]
];