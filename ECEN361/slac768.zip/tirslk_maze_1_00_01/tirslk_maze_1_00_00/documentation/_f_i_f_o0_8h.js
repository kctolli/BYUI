var _f_i_f_o0_8h =
[
    [ "FIFOFAIL", "_f_i_f_o0_8h.html#a5e32948644a47e4f3ce03dbfd93fbcaa", null ],
    [ "FIFOSUCCESS", "_f_i_f_o0_8h.html#ae68463d3e90d2f00b15c73bdb92bb0f7", null ],
    [ "RX0FIFOSIZE", "_f_i_f_o0_8h.html#a3223b8e91da6fbcfe60f76b70402ef2a", null ],
    [ "TX0FIFOSIZE", "_f_i_f_o0_8h.html#abdf785e04495ffe30f316ac526bcae12", null ],
    [ "RxFifo0_Get", "_f_i_f_o0_8h.html#ac7c45c957c34358649129833a8e4944a", null ],
    [ "RxFifo0_Init", "_f_i_f_o0_8h.html#a06eb53f9cade465c55296709e95d4114", null ],
    [ "RxFifo0_Put", "_f_i_f_o0_8h.html#a92f3417eb801d56616b076240d69a1b3", null ],
    [ "RxFifo0_Size", "_f_i_f_o0_8h.html#a5df480c504a961365182a947dff8b868", null ],
    [ "TxFifo0_Get", "_f_i_f_o0_8h.html#a046913ef7f02e9348b18a5572919bf5d", null ],
    [ "TxFifo0_Init", "_f_i_f_o0_8h.html#a1065279652513ffaf4285d64c23f8c3c", null ],
    [ "TxFifo0_Put", "_f_i_f_o0_8h.html#a3794146989f0f2ae5bf7497e574aaaec", null ],
    [ "TxFifo0_Size", "_f_i_f_o0_8h.html#a5f33f9642a00824e986634be918d6754", null ]
];