var annotated_dup =
[
    [ "characteristics", "structcharacteristics.html", "structcharacteristics" ],
    [ "Cmd_t", "struct_cmd__t.html", "struct_cmd__t" ],
    [ "command", "structcommand.html", "structcommand" ],
    [ "NotifyCharacteristics", "struct_notify_characteristics.html", "struct_notify_characteristics" ],
    [ "ScoreboardElement", "struct_scoreboard_element.html", "struct_scoreboard_element" ],
    [ "State", "struct_state.html", "struct_state" ]
];