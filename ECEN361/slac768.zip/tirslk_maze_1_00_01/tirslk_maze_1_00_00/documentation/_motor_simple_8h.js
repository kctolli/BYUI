var _motor_simple_8h =
[
    [ "Motor_BackwardSimple", "_motor_simple_8h.html#ab93cbef78c3f040f8f8d32e29db1c156", null ],
    [ "Motor_ForwardSimple", "_motor_simple_8h.html#a940872458c49d22b0f774a1a5c8c53ff", null ],
    [ "Motor_InitSimple", "_motor_simple_8h.html#ab2d93801c3bfddcd52b5993ff339f2d1", null ],
    [ "Motor_LeftSimple", "_motor_simple_8h.html#a7d00bb98d92fd93784da534ef6851cfb", null ],
    [ "Motor_RightSimple", "_motor_simple_8h.html#a131a992d2cb93e34227701ea7ca8fa8a", null ],
    [ "Motor_StopSimple", "_motor_simple_8h.html#a556dfe2356726bbf5f8168362c79b838", null ]
];