var _switch_8h =
[
    [ "Switch_Init", "_switch_8h.html#a1c787c932acfeaea4ff8f7ce68b315bb", null ],
    [ "Switch_Input", "_switch_8h.html#aa078298780f13e79a82330844f71bb45", null ]
];