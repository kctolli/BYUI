var _timer_a1_8h =
[
    [ "TimerA1_Init", "_timer_a1_8h.html#a1f1104a1081677214dc6e626f666ac53", null ],
    [ "TimerA1_Stop", "_timer_a1_8h.html#a704151518ec3770732ad6e2e5d59a50d", null ]
];