var struct_state =
[
    [ "delay", "struct_state.html#a458421a43d4f6dc515faf427bf579d00", null ],
    [ "Next", "struct_state.html#af0784c8d3bbecfb9ddf716949423c68b", null ],
    [ "next", "struct_state.html#ad30e2f0a484727bb04f48d9715f16376", null ],
    [ "Out", "struct_state.html#a88553592388cd23aab5fb5d7a6c16cb4", null ],
    [ "out", "struct_state.html#ab27775f0ed2b042b439a7431fbe311eb", null ],
    [ "Time", "struct_state.html#afb4952bec365dc441b645a2ba0fc0379", null ]
];