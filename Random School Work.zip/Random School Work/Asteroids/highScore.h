#pragma once
#include "point.h"
#include "uiDraw.h"

class HighScore
{
private:
   Point pNum;
   Point pWord;
   int high;

   int value;
public:
   // Default
   HighScore() : pNum(165, 190), pWord(90, 180), value(0) {}

   void changeHighScore(int fuel) { if (fuel > value) high = fuel; }
   int gethighScore() const { return high; }

   void draw() { drawText(pWord, "High Score"); drawNumber(pNum, high); }
};