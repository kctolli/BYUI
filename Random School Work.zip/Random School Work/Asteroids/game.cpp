/*********************************************************************
 * File: game.cpp
 * Description: Contains the implementaiton of the game class
 *  methods.
 *
 *********************************************************************/

#include "game.h"

// These are needed for the getClosestDistance function...
#include <limits>
#include <algorithm>
#include <iostream>
#include "flyingObject.h"
#include "asteroid.h"
#include "point.h"
#include "velocity.h"

using namespace std;

/*****************************************************
* Constructor: GAME(Point, Point)
*****************************************************/
Game::Game(Point tl, Point br)
   : topLeft(tl), bottomRight(br), ship(br), numOfAsteroids(0), 
   score(0), level(0), numForAsteroids(1)
{
   levelUp(0); // --> Just starting you off with a single asteroid
}

Game::~Game()
{
   cleanUpZombies();
}

/*****************************************************
* Function: HANDLE INPUT
* Handles any input from keyboard inputs
*****************************************************/
void Game::handleInput(const Interface & ui)
{
   HighScore highScore;
   if (ship.isAlive())
   {
      if (ui.isRight())
      {
         ship.rotateRight();
      }
      if (ui.isLeft())
      {
         ship.rotateLeft();
      }
      if (ui.isUp())
      {
         ship.moveForward();
         ship.setThrust(true);
      }
      else
      {
         ship.setThrust(false);
      }

      // Firing standard bullets
      if (ui.isSpace() && ship.getVelocity().getDx() != 0
         && ship.getVelocity().getDy() != 0)
      {
         Bullet newBullet;
         newBullet.fire(ship.getPoint(), ship.getAngle());

         bullets.push_back(newBullet);
      }

      // Machine gun if pressed down
      if (ui.isDown() && (ship.getVelocity().getDx() != 0 ||
         ship.getVelocity().getDy() != 0))
      {
         largeFlame(ship.getPoint(), ship.getThrust());

         Bullet newBullet;
         newBullet.fire(ship.getPoint(), ship.getAngle());
         largeFlame(ship.getPoint(), true);
         bullets.push_back(newBullet);
      }


   }

   // Giving option to restart if you have enough lives
   if (!ship.isAlive() && ship.getLives() != 0)
   {
      if (ui.isSpace())
      {
         //highScore.changeHighScore(score);
         ship.resetShip();
      }
   }


}

/*****************************************************
* Function: IS ON SCREEN
* Determines whether an object is within a screen
*****************************************************/
bool Game::isOnScreen(const Point & point)
{
   return false;
}

/*****************************************************
* Function: ADVANCE
* Advance bullets
*****************************************************/
void Game::advance()
{
   advanceBullets();
   advanceAsteroids();
  
   handleCollision();
   cleanUpZombies();
}

/*****************************************************
* Function: DRAW
* Handles drawing all objects on the screen
*****************************************************/
void Game::draw(const Interface & ui)
{
   // Draw Asteroids
   for (list<Asteroid*>::iterator it = asteroids.begin(); 
      it != asteroids.end(); it++)
   {
      (*it)->count();
      (*it)->draw();
   }
   
   // Draw Ship
   ship.draw();

   // Draw Lives
   ship.drawLives();

   // Crash report
   if (!ship.isAlive() && ship.getLives() != 0)
   {
      drawText(Point(-55, 100), "You have crashed!");
      drawText(Point(-55, 80), "Press 'Space'-bar to continue...");

      ship.setAngle(random(0.0, 180.0));
   }

   // Game Over Report
   if (!ship.isAlive() && ship.getLives() == 0)
   {
      drawText(Point(-55, 100), "GAME OVER!");
      drawText(Point(-55, 80), "Your score: ");
      drawNumber(Point(28, 90), highScore.gethighScore());
      //highScore.draw();
   }

   // Starting Message
   if (numOfAsteroids == 5 && ship.getVelocity().getDx() == 0 &&
      ship.getVelocity().getDy() == 0 && level == 1)
   {
      drawText(Point(-20, 150), "Welcome to ASTEROIDS!");
      drawLander(Point(-30, 132));
      drawText(Point(0, 130), "by Anthony Campbell");
      drawText(Point(-20, 100), "Press the 'up' key to move forward/start");
      drawText(Point(-20, 80), "Press 'left' or 'right' keys to change direction");
      drawText(Point(-20, 60), "Press 'space' key to shoot single bullets");
      drawText(Point(-20, 40), "Hold 'down' key for machine gun");
   }

   // Display current level on top center of screen
   drawText(Point(-55, 388), "LEVEL: ");
   drawNumber(Point(-5.0, 396.0), level);

   // Draw Bullets
   for (list<Bullet>::iterator it = bullets.begin(); 
      it != bullets.end(); it++)
   {
      if (it->isAlive())
      {
         it->draw();
      }
   }

   // Leveling up
   if (numOfAsteroids == 0)
   {
      levelUp(numOfAsteroids);
      createAsteroid(1);
   }

   // Put the score on the screen
   Point scoreLocation;
   scoreLocation.setX(topLeft.getX() + 5);
   scoreLocation.setY(topLeft.getY() - 5);

   drawNumber(scoreLocation, score);

   // Landing pad for starting position of ship
   if (ship.getVelocity().getDx() == 0 && ship.getVelocity().getDy() == 0)
   {
      drawPolygon(Point(ship.getPoint()), 20, 6, 90);
   }

}

/*****************************************************
* Function: ADVANCE BULLETS
* Advances bullets during gameplay
*****************************************************/
void Game::advanceBullets()
{
   // If alive, shoot from tip of ship
   for (list<Bullet>::iterator it = bullets.begin(); it != bullets.end(); it++)
   {
      if ((*it).isAlive())
      {
         (*it).advance();
      }
   }
}

/*****************************************************
* Function: ADVANCE ASTEROIDS
* Advances bullets during gameplay
*****************************************************/
void Game::advanceAsteroids()
{
   for (list<Asteroid*>::iterator it = asteroids.begin(); it != asteroids.end(); it++)
   {
      if ((*it)->isAlive())
      {
         (*it)->advance();
      }
      else
      {
         cleanUpZombies();
      }
   }
}

/*****************************************************
* Function: CREATE ASTEROID
* Creates any size asteroid to be drawn at a given function
*****************************************************/
Asteroid* Game::createAsteroid(int num)
{
   Asteroid* newAsteroid = NULL; // -> clear the new asteroid
   //newAsteroid = new LargeAsteroid();

   for (int i = 0; i < numForAsteroids; i++)  // --> There will be 5 asteroids at 1 time
   {
      //cleanUpZombies();
      numOfAsteroids++;
      newAsteroid = new LargeAsteroid();
      asteroids.push_back(newAsteroid);
   }

   //numForAsteroids *= 2;
   return newAsteroid;
}

/*****************************************************
* Function: HANDLE COLLISION
* Handles any collision between objects
*****************************************************/
void Game::handleCollision()
{
   HighScore highScore;
   Ship *shi = &ship;
   for (list<Asteroid*>::iterator itt = asteroids.begin(); itt != asteroids.end(); itt++)
   {
      // Ship VS Asteroids
      if ((getClosestDistance((**itt), *shi)) <= (1 + (*itt)->getRadius())
         && (*itt)->isAlive() && shi->isAlive() && shi->getVelocity().getDx() != 0
         && shi->getVelocity().getDy() != 0)
      {
         breakApart();
         shi->setLife(shi->getLives() - 1);
         shi->kill();
         highScore.changeHighScore(score);
         score = 0;
      }
      // Bullets VS Asteroids
      for (list<Bullet>::iterator it = bullets.begin(); it != bullets.end(); it++)
      {
         if (getClosestDistance((**itt), (*it)) <= (1 + ((*itt)->getRadius())) 
            && (*itt)->isAlive() && (*it).isAlive())
         {
            numOfAsteroids--;
            (*it).kill(); 
            cleanUpZombies();

            int points = (*itt)->hit();
            score += points;
         }
      }     
   }

   // Breaking asteroids apart
   int num = 0;
   for (list<Asteroid*>::iterator itt = asteroids.begin(); itt != asteroids.end(); itt++)
   {
      Asteroid* newAsteroid = NULL; // -> clear the new asteroid

      // Large Asteroid Collision
      if (!((*itt)->isAlive()) && (*itt)->getRadius() == BIG_ROCK_SIZE &&
         (*itt) != NULL)
      {
         for (int num = 0; num < 3; num++)
            switch (num)
            {
            case 0:
               newAsteroid = new MediumAsteroid((*itt)->getVelocity().getDx(),
                  (*itt)->getVelocity().getDy() + 1);
               newAsteroid->setPoint((*itt)->getPoint());
               itt = asteroids.insert(itt, newAsteroid);
               ++itt;
               numOfAsteroids++;
               break;

            case 1:
               newAsteroid = new MediumAsteroid((*itt)->getVelocity().getDx(),
                  (*itt)->getVelocity().getDy() - 1);
               newAsteroid->setPoint((*itt)->getPoint());
               itt = asteroids.insert(itt, newAsteroid);
               ++itt;
               numOfAsteroids++;
               break;

            case 2:
               newAsteroid = new SmallAsteroid((*itt)->getVelocity().getDx() + 2,
                  (*itt)->getVelocity().getDy());
               newAsteroid->setPoint((*itt)->getPoint());
               itt = asteroids.insert(itt, newAsteroid);
               ++itt;
               numOfAsteroids++;
               break;
            }
      }
   }
   for (list<Asteroid*>::iterator itt = asteroids.begin(); itt != asteroids.end(); itt++)
   {
      Asteroid* newAsteroid = NULL; // -> clear the new asteroid
      // Medium Asteroid Collision
      if (!((*itt)->isAlive()) && (*itt)->getRadius() ==
         MEDIUM_ROCK_SIZE && (*itt) != NULL)
      {
         //newAsteroid = NULL;
         for (int num = 0; num < 2; num++)
            switch (num)
            {
            case 0:
               newAsteroid = new SmallAsteroid((*itt)->getVelocity().getDx() + 3,
                  (*itt)->getVelocity().getDy());
               newAsteroid->setPoint((*itt)->getPoint());
               itt = asteroids.insert(itt, newAsteroid);
               ++itt;
               numOfAsteroids++;
               break;

            case 1:
               newAsteroid = new SmallAsteroid((*itt)->getVelocity().getDx() - 3,
                  (*itt)->getVelocity().getDy());
               newAsteroid->setPoint((*itt)->getPoint());
               itt = asteroids.insert(itt, newAsteroid);
               ++itt;
               numOfAsteroids++;
               break;
            }
      }
   }

}

void Game::breakApart()
{
   // Breaking asteroids apart
   int num = 0;
   for (list<Asteroid*>::iterator itt = asteroids.begin(); itt != asteroids.end(); itt++)
   {
      Asteroid* newAsteroid = NULL; // -> clear the new asteroid

                                    // Large Asteroid Collision
      if (!((*itt)->isAlive()) && (*itt)->getRadius() == BIG_ROCK_SIZE &&
         (*itt) != NULL)
      {
         for (int num = 0; num < 3; num++)
            switch (num)
            {
            case 0:
               newAsteroid = new MediumAsteroid((*itt)->getVelocity().getDx(),
                  (*itt)->getVelocity().getDy() + 1);
               newAsteroid->setPoint((*itt)->getPoint());
               itt = asteroids.insert(itt, newAsteroid);
               ++itt;
               numOfAsteroids++;
               break;

            case 1:
               newAsteroid = new MediumAsteroid((*itt)->getVelocity().getDx(),
                  (*itt)->getVelocity().getDy() - 1);
               newAsteroid->setPoint((*itt)->getPoint());
               itt = asteroids.insert(itt, newAsteroid);
               ++itt;
               numOfAsteroids++;
               break;

            case 2:
               newAsteroid = new SmallAsteroid((*itt)->getVelocity().getDx() + 2,
                  (*itt)->getVelocity().getDy());
               newAsteroid->setPoint((*itt)->getPoint());
               itt = asteroids.insert(itt, newAsteroid);
               ++itt;
               numOfAsteroids++;
               break;
            }
      }

       // Medium Asteroid Collision
      if (!((*itt)->isAlive()) && (*itt)->getRadius() == 
         MEDIUM_ROCK_SIZE && (*itt) != NULL)
      {
         newAsteroid = NULL;
         for (int num = 0; num < 2; num++)
            switch (num)
            {
            case 0:
               newAsteroid = new SmallAsteroid((*itt)->getVelocity().getDx() + 3, 
                  (*itt)->getVelocity().getDy());
               newAsteroid->setPoint((*itt)->getPoint());
               itt = asteroids.insert(itt, newAsteroid);
               ++itt;
               numOfAsteroids++;
               break;

            case 1:
               newAsteroid = new SmallAsteroid((*itt)->getVelocity().getDx() -3,
                  (*itt)->getVelocity().getDy());
               newAsteroid->setPoint((*itt)->getPoint());
               itt = asteroids.insert(itt, newAsteroid);
               ++itt;
               numOfAsteroids++;
               break;
            }
      }
   }
}

/*****************************************************
* Function: CLEAN UP ZOMBIES
* Erases all objects that have beeen collided with bullets
*****************************************************/
void Game::cleanUpZombies()
{
   list<Asteroid*>::iterator it = asteroids.begin();
   while (it != asteroids.end())
   {
      Asteroid *ast = *it;

      if (!ast->isAlive())
      {
         delete ast;  
         ast = NULL; 
         it = asteroids.erase(it);
      }
      else
      {
         it++;
      }
   }
}

/**********************************************************
* Function: GET CLOSEST DISTANCE
* Description: Determine how close these two objects will
*                 get in between the frames.
**********************************************************/
float Game::getClosestDistance(const FlyingObject &obj1, const FlyingObject &obj2) const
{
   // find the maximum distance traveled
   float dMax = max(abs(obj1.getVelocity().getDx()), abs(obj1.getVelocity().getDy()));
   dMax = max(dMax, abs(obj2.getVelocity().getDx()));
   dMax = max(dMax, abs(obj2.getVelocity().getDy()));
   dMax = max(dMax, 0.1f); // when dx and dy are 0.0. Go through the loop once.

   float distMin = std::numeric_limits<float>::max();
   for (float i = 0.0; i <= dMax; i++)
   {
      Point point1(obj1.getPoint().getX() + (obj1.getVelocity().getDx() * i / dMax),
         obj1.getPoint().getY() + (obj1.getVelocity().getDy() * i / dMax));
      Point point2(obj2.getPoint().getX() + (obj2.getVelocity().getDx() * i / dMax),
         obj2.getPoint().getY() + (obj2.getVelocity().getDy() * i / dMax));

      float xDiff = point1.getX() - point2.getX();
      float yDiff = point1.getY() - point2.getY();

      float distSquared = (xDiff * xDiff) + (yDiff * yDiff);

      distMin = min(distMin, distSquared);
   }

   return sqrt(distMin);
}

/**********************************************************
* Function: LEVEL UP
* Description: Changes game difficulty by incrementing asteroids
*                 and reset the lander
**********************************************************/
void Game::levelUp(int numOfAsteroids)
{
      if (numOfAsteroids == 0)
      {
            createAsteroid(numForAsteroids);
            numForAsteroids *= 2;
            level += 1;
            ship.resetShip();
      }
}