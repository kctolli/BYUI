#include "velocity.h"

/*****************************************************
* Function: SET MAGNITUDE AND DIRECTION
* 
*****************************************************/
void Velocity::setMagnitudeAndDirection(float magnitude, float direction)
{
   this->dx = magnitude * (-sin(M_PI / 180.0 * direction));
   this->dy = magnitude * (cos(M_PI / 180.0 * direction));

   //addDx(dx);
   //addDy(dy);
}

/*****************************************************
* Function: SET MAGNITUDE
*
*****************************************************/
//void Velocity::setMagnitude(float magnitude)
//{
//   this->magnitude = magnitude;
//  // float dx = magnitude * (-sin(M_PI / 180.0 * angle));
//   //float dy = magnitude * (cos(M_PI / 180.0 * angle));
//
//}

/*****************************************************
* Function: SET DIRECTION
*
*****************************************************/
void Velocity::setDirection(float angle)
{
   this->angle = angle;
}

/*****************************************************
* Function: GET DIRECTION
*
*****************************************************/
float Velocity::getDirection() const
{
   return angle;
}

/*****************************************************
* Function: GET MAGNITUDE
*
*****************************************************/
float Velocity::getMagnitude() const
{
   return magnitude;
}