#ifndef rocks_h
#define rocks_h

#define BIG_ROCK_SIZE 16
#define MEDIUM_ROCK_SIZE 8
#define SMALL_ROCK_SIZE 4

#define BIG_ROCK_SPIN 2
#define MEDIUM_ROCK_SPIN 5
#define SMALL_ROCK_SPIN 10

#include "flyingObject.h"
#include "uiDraw.h"

// Define the following classes here:
//   Rock
//   BigRock
//   MediumRock
//   SmallRock
class Rocks : public FlyingObject
{
    protected:
    int lives;  // --> toughBird and bonusLander will have multiple lives
    int radius; // --> size of the bird
    public:
    Rocks() : radius(20)
    {
        alive = true; velocity.setDx(3);
        velocity.setDy(3);
        point.setX(random(-200, 200));
        point.setY(random(-200, 200));
        if (point.getY() > 0) // --> adjust starting velocity according to start
        {
            velocity.setDy(-3);
        }
    }

    int getRadius()            { return radius; }
    void setRadius(int radius) { this->radius = radius; }

    virtual void draw() = 0;
    virtual int hit() = 0;

};

#endif /* rocks_h */
