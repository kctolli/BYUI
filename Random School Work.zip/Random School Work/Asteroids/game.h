/*********************************************************************
 * File: game.h
 * Description: Defines the game class for Asteroids
 *
 *********************************************************************/

#ifndef GAME_H
#define GAME_H

#include <vector>
#include <list>

#include "uiDraw.h"
#include "uiInteract.h"
#include "point.h"
#include "ship.h"
#include "bullet.h"
#include "asteroid.h"
#include "highScore.h"

 /*********************************************************************
 * CLASS: Game
 * Description: Runs the game in an order
 *********************************************************************/
class Game
{
private:
   // Screen size
   Point topLeft;
   Point bottomRight;

   int score;           // --> Handles Score
   int level;           // --> Level will determin number of asteroids
   int numForAsteroids; // --> To by how much to increment asteroids
   int numOfAsteroids;  // --> To know when to level up

   // Characters --> ship, bullets, asteroids
   Ship ship;
   std::list<Bullet> bullets;
   std::list<Asteroid*> asteroids;

   // Logic
   bool isOnScreen(const Point & point);
   void advanceBullets();
   void advanceAsteroids();
   Asteroid* createAsteroid(int num);

   void handleCollision();
   void breakApart();
   void cleanUpZombies();

   // Handle collision distance
   float getClosestDistance(const FlyingObject &asteroid,
      const FlyingObject &ship) const;

   Ship getShip() { return ship; }

   // Leveling up
   void levelUp(int numOfAsteroids);
   HighScore highScore;

public:
   /*********************************************
   * Constructor
   * Initializes the game
   *********************************************/
   Game(Point tl, Point br);
   ~Game();

   /*********************************************
   * Function: handleInput
   * Description: Takes actions according to whatever
   *  keys the user has pressed.
   *********************************************/
   void handleInput(const Interface & ui);

   /*********************************************
   * Function: advance
   * Description: Move everything forward one
   *  step in time.
   *********************************************/
   void advance();

   /*********************************************
   * Function: draw
   * Description: draws everything for the game.
   *********************************************/
   void draw(const Interface & ui);
};


#endif /* GAME_H */