#ifndef flyingObject_h
#define flyingObject_h


#include "point.h"
#include "velocity.h"
#include "uiDraw.h"
#include <math.h>
#include <vector>
#include "time.h"


/*********************************************************************
* CLASS: FlyingObject
* Description: Is a base class that will create an object that moves 
*********************************************************************/
class FlyingObject
{
protected:
   Point point;
   Velocity velocity;
   bool alive;
   float angle;
   int spin;
   int life;

public:
   // Constructors
   FlyingObject() : point(0, 0), velocity(0, 0), alive(true), 
      angle(0), spin(0), life(0) {}

   // Getters
   virtual Point getPoint()   const             { return point;      }
   virtual Velocity getVelocity() const  { return velocity;   }
   //int getScore() const { return score; }

   // Setters
   virtual void setPoint(Point point)                         { this->point = point;         }
   virtual void setVelocity(Velocity velocity)  { this->velocity = velocity;  }
   //void getScore(int score) { this->score = score; }

   // Object conditions
   virtual bool isAlive()     { return alive;  }
   virtual void kill();
   virtual void advance();
   void count();
};

#endif /* flyingObject_h */