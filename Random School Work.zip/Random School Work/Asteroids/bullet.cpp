#include "bullet.h"
#include <iostream>
using namespace std;

#define _USE_MATH_DEFINES
#include <cmath>
#include <math.h>
// Put your bullet methods here

Bullet::Bullet() 
{
   alive = true;  
   point.setX(0); 
   point.setY(0);
   life = 40;
}
void Bullet::draw()
{
   time_t timer;
   struct tm  countDown = { 0 };
   
   point.setX(point.getX() + velocity.getDx());
   point.setY(point.getY() + velocity.getDy());
   drawDot(point); 
   life--;
   if (life == 0)
   {
      alive = false;
   }
}

void Bullet::fire(Point point, float angle)
{
   // Make sure starting point of bullet is with ship
   this->point.setX(point.getX());
   this->point.setY(point.getY());

   // Bullets will follow the velocity and angle of the gun
   float dx = (velocity.getDx() + BULLET_SPEED) * (-sin(M_PI / 180.0 * angle));
   float dy = (velocity.getDy() + BULLET_SPEED) * (cos(M_PI / 180.0 * angle));

   velocity.addDx(dx);
   velocity.addDy(dy);
}

void Bullet::advance()
{
   point.setX(point.getX() + velocity.getDx());
   point.setY(point.getY() + velocity.getDy());

   if (point.getX() > 400 || point.getY() > 400 || point.getX() < -400
      || point.getY() < -400)
   {
      point.setX(point.getX() * -1);
      point.setY(point.getY() * -1);
   }
}

void Bullet::kill()
{
   this->alive = false;
}