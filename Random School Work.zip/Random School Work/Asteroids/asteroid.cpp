#include "asteroid.h"


/*****************************************************
* Constructor: ASTEROID
*
*****************************************************/
Asteroid::Asteroid() : lives(1), radius(20)
{
   alive = true; 
   //velocity.setDx(3);
   //velocity.setDy(3);
   point.setX(random(-200, 200));
   point.setY(random(-200, 200));
   velocity = Velocity(random(-4, 4), random(-4, 4));
}

Asteroid::Asteroid(float dx, float dy)
{
   velocity.setDx(dx);
   velocity.setDy(dy);
}

LargeAsteroid::LargeAsteroid()
{
   //velocity.setMagnitudeAndDirection(1.0, random(1.0, 180.0)); 
   setRadius(BIG_ROCK_SIZE);
   alive = true;
}

/*****************************************************
* Function: LARGE - DRAW
* Draws large asteroid
*****************************************************/
void LargeAsteroid::draw()
{
   drawLargeAsteroid(point, spin * BIG_ROCK_SPIN);
}

/*****************************************************
* Function: LARGE - HIT
* Breaks apart a large asteroid and returns 2 medium and 1 small asteroid
*****************************************************/
int LargeAsteroid::hit()
{
   kill();
   //drawMediumAsteroid(point, spin * MEDIUM_ROCK_SPIN);
   return 1;
}

MediumAsteroid::MediumAsteroid(float dx, float dy)
{
   velocity.setDx(dx);
   velocity.setDy(dy);
}

MediumAsteroid::MediumAsteroid()
{
   //velocity.setMagnitudeAndDirection(5.0, random(1.0, 180.0));
   Velocity((float)5.0, random(1.0, 180.0));
   setRadius(MEDIUM_ROCK_SIZE);
   alive = true;
}

/*****************************************************
* Function: MEDIUM - DRAW
* Draws a medium asteroid
*****************************************************/
void MediumAsteroid::draw()
{
   alive = true;
   drawMediumAsteroid(point, spin * MEDIUM_ROCK_SPIN);
}

/*****************************************************
* Function: MEDIUM - HIT
*  
*****************************************************/
int MediumAsteroid::hit()
{
   kill();
   //breakApart();
   return 2;
}


SmallAsteroid::SmallAsteroid(float dx, float dy)
{
   velocity.setDx(dx);
   velocity.setDy(dy);
}

SmallAsteroid::SmallAsteroid()
{
   //velocity.setMagnitudeAndDirection((float)10.0, random(1.0, 180.0)); 
   Velocity((float)10.0, random(1.0, 180.0));
   setRadius(SMALL_ROCK_SIZE);
   alive = true;
}

/*****************************************************
* Function: SMALL - DRAW
*
*****************************************************/
void SmallAsteroid::draw()
{
   drawSmallAsteroid(point, spin * SMALL_ROCK_SPIN);
}

/*****************************************************
* Function: SMALL HIT
*
*****************************************************/
int SmallAsteroid::hit()
{
   kill();
   //breakApart();
   return 3;
}