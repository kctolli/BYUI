#pragma once
#include "flyingObject.h"
#include "uiDraw.h"
#include "velocity.h"
#include <iostream>
using namespace std;

#define BIG_ROCK_SIZE 16
#define MEDIUM_ROCK_SIZE 8
#define SMALL_ROCK_SIZE 4

#define BIG_ROCK_SPIN 2
#define MEDIUM_ROCK_SPIN 5
#define SMALL_ROCK_SPIN 10

/*********************************************************************
* CLASS: Asteroid
* Description: Parent class to all the other asteroids
*********************************************************************/
class Asteroid : public FlyingObject
{
protected:
   int lives;
   int radius;
   bool alive;
   //Velocity velocity;
public:
   // CONSTRUCTORS
   Asteroid();
   Asteroid(float dx, float dy);

   // GETTERS
   int getLives()                           { return lives;               }
   int getRadius()                        { return radius;            }
   float  getAngle(float angle)     { return angle;            }
   Point getPoint()   const { return point; }
   Velocity getVelocity() const { return velocity; }

   // Setters



   // SETTERS
   void setLives(int lives)            { this->lives = lives;      }
   void setRadius(int radius)      { this->radius = radius; }
   virtual void setPoint(Point point) { this->point = point; }
   virtual void setVelocity(Velocity velocity) { this->velocity = velocity; }

   // PURE VIRTUAL FUNCTIONS
   //virtual vector<Asteroid*> breakApart() = 0;
   virtual void draw() = 0;
   virtual int hit() = 0;
};

/*********************************************************************
* CLASS: BigAsteroid
* Description: A large asteroid...
*********************************************************************/
class LargeAsteroid : public Asteroid
{ 
    public:
    LargeAsteroid();
    void draw();
    int hit();
};

/*********************************************************************
* CLASS: MediumAsteroid
* Description: A medium sized asteroid...
*********************************************************************/
class MediumAsteroid : public Asteroid
{
    public:
    MediumAsteroid(float dx, float dy);
    MediumAsteroid();
    void draw();
    int hit();
};

/*********************************************************************
* CLASS: SmallAsteroid
* Description: A medium sized asteroid
*********************************************************************/
class SmallAsteroid : public Asteroid
{
    public:
    SmallAsteroid(float dx, float dy);
    SmallAsteroid(); 
    void draw();
    int hit();
};