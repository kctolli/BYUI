#ifndef ship_h
#define ship_h

#include "flyingObject.h"
#include "uiDraw.h"

#define _USE_MATH_DEFINES // for C++
#define SHIP_SIZE 10

#define ROTATE_AMOUNT 6
#define THRUST_AMOUNT 0.5


/*********************************************************************
* CLASS: Ship
* Description: Creates a ship as a flying object and defines it's properties
*********************************************************************/
class Ship : public FlyingObject
{
protected:
   Point point;
   bool thrust;
   bool alive;
   
public:
   // Constructor
   Ship(const Point & point);

   // Getters
   bool getThrust()          { return thrust;   }
   bool isAlive()               { return alive;     }
   float getAngle() const { return angle;    }
   Point getPoint()   const { return point; }
   Velocity getVelocity() const { return velocity; }
   int getLives() const { return life; }

   // Setters
   void setThrust(bool thrust)   { this->thrust = thrust; }
   void setAngle(float angle)    { this->angle = angle; }
   void setPoint(Point point) { this->point = point; }
   void setVelocity(Velocity velocity) { this->velocity = velocity; }
   void setLife(int life) { this->life = life; }

   // Drawing
   void draw();
   void drawLives();
   void kill();
   void resetShip();

   // Movement
   void moveForward();
   void rotateLeft();
   void rotateRight();
};

#endif /* ship_h */