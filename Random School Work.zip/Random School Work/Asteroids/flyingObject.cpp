#include "flyingObject.h"

/*****************************************************
* Function: KILL
* For killing an object that is hit
*****************************************************/
void FlyingObject::kill()
{
   this->alive = false;
}

/*****************************************************
* Function: ADVANCE
* Advances any object
*****************************************************/
void FlyingObject::advance()
{
   point.setX(point.getX() + velocity.getDx());
   point.setY(point.getY() + velocity.getDy());

   if (point.getX() > 400 || point.getY() > 400 || point.getX() < -400
         || point.getY() < -400)
   {
      point.setX(point.getX() * -1);
      point.setY(point.getY() * -1);
   }
}

/*****************************************************
* Function: COUNT
* For spinning
*****************************************************/
void FlyingObject::count()
{
   this->spin = spin++;
   if (spin == 360)
   {
      spin = 0;
   }
}