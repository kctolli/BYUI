#ifndef VELOCITY_H
#define VELOCITY_H
#include <math.h>
#define _USE_MATH_DEFINES
#include <cmath>
class Velocity
{
private:
   float dx;
   float dy;
   float magnitude;
   float angle;

public:
   // Constructors
   Velocity() : dx(0), dy(0), magnitude(0), angle(0) {}
   Velocity(float dx, float dy) : dx(dx), dy(dy) {}

   // Getters
   float getDx() const { return dx; }
   float getDy() const { return dy; }
   float getDirection() const;
   float getMagnitude() const;

   // Setters
   void setDx(float dx) { this->dx = dx; }
   void setDy(float dy) { this->dy = dy; }

   void setMagnitudeAndDirection(float magnitude, float direction);
   //void setMagnitude(float magnitude);
   void setDirection(float angle);

   // Adders
   void addDx(float value) { dx += value; }
   void addDy(float value) { dy += value; }
   void add(const Velocity &rhs)
   {
      dx += rhs.dx;
      dy += rhs.dy;
   }
};


#endif