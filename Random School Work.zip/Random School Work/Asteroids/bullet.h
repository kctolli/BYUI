#ifndef bullet_h
#define bullet_h

#define BULLET_SPEED 5
#define BULLET_LIFE 40

#include "flyingObject.h"
#include "uiDraw.h"



/*********************************************************************
* CLASS: Bullet
* Description: Draws a bullet that the ship is going to shoot
*********************************************************************/
class Bullet : public FlyingObject
{
private:
   Point point;
   Velocity velocity;
public:
   Bullet();
   void draw();
   void fire(Point point, float angle);
   void advance();
   void kill();   

   // Getters
   virtual Point getPoint()   const { return point; }
   virtual Velocity getVelocity() const { return velocity; }

   // Setters
   virtual void setPoint(Point point) { this->point = point; }
   virtual void setVelocity(Velocity velocity) { this->velocity = velocity; }
};



#endif /* bullet_h */