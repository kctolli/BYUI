#include "ship.h"
#include <iostream>
using namespace std;
#include <math.h>
#include <iomanip>

/***********************************************************
* Constructor: SHIP()
* Description: Sets all defaults to 0
***********************************************************/
Ship::Ship(const Point & point) : point(0, 0), thrust(false), alive(true)
{ 
   angle = ROTATE_AMOUNT; 
   //velocity.setDirection(0);
   velocity.setDx(0);
   velocity.setDy(0);
   life = 5;
}

/***********************************************************
* Function: DRAW
* Description: Draws the ship to move and loop across the screen
***********************************************************/
void Ship::draw() 
{
   drawShip(point, angle, thrust, false);
   point.setX(point.getX() + velocity.getDx());
   point.setY(point.getY() + velocity.getDy());

   if (point.getX() > 400 || point.getY() > 400 || point.getX() < -400
      || point.getY() < -400)
   {
      point.setX(point.getX() * -1);
      point.setY(point.getY() * -1);
   }
}

void Ship::drawLives()
{
   drawText(Point(250, 383), "LIVES: ");
   int num = 0;
   for (int i = 0; i < life; i++)
   {
      drawShip(Point(300 - num, 388), 0, false, false);
      num -= 15;
      if (life == 0)
      {
         num = 0;
      }
   }
}

void Ship::kill()
{
   alive = false;
   //thrust = false;
   //largeFlame(point, random(0, 1));
  
   //setAngle(random(0.0, 180.0));
   drawShip(point, random(0.0, 180.0), false, true);
}

void Ship::resetShip()
{
   this->velocity.setDx(0);
   this->velocity.setDy(0);
   this->setPoint(0);
   this->setAngle(0);
   thrust = false;
   alive = true;
}

/***********************************************************
* Function: MOVE FORWARD
* Description: Moves the ship forward to where its pointing
***********************************************************/
void Ship::moveForward()
{
   if (isAlive())
   {
      float dx = 0.5 * (-sin(M_PI / 180.0 * angle));
      float dy = 0.5 * (cos(M_PI / 180.0 * angle));

      velocity.addDx(dx);
      velocity.addDy(dy);
   }
}

/***********************************************************
* Function: ROTATE LEFT
* Description: Rotates the Ship left
***********************************************************/
void Ship::rotateLeft()
{
   if (isAlive())
   {
       this->angle += ROTATE_AMOUNT;
   }
}

/***********************************************************
* Function: ROTATE RIGHT
* Description: Rotates the ship right
***********************************************************/
void Ship::rotateRight()
{
   if (isAlive())
   {
      this->angle -= ROTATE_AMOUNT;
   }
}