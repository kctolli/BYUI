package edu.byui.cs.teamactivity06asynctask;

import android.content.Context;
import android.os.AsyncTask;
import android.widget.ProgressBar;
import android.widget.Toast;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

/**
 * Created by sburton on 2/14/18.
 */

// This class is very similar to the LoadFileTask.
// **** Please read the comments for this one first, before the LoadFileTask ****

public class CreateFileTask extends AsyncTask<String, Integer, Void > {
    // The generic parameters in that extends statement are a little confusing:

    // The first one (String) says that we are going to pass a String (or technically a
    // possible array of Strings) as an argument to the .execute function
    // when this starts running. It will then pass it along to us in this class
    // as a parameter to the doInBackground method.

    // The second one (Integer) says that when we call the publishProgress method
    // we will give it an Integer (or again, possibly an array of Integers) and then
    // it will pass those along to us as a parameter to the onProgressUpdate method.

    // The third one (Void) specifies the return type of the doInBackground method
    // that could then be returned back to our original method call in the
    // mainActivity. In our case, we don't need to return anything, so we can just
    // list it as "Void" (notice the capital V).



    // These member variables will hold references to the calling Activity or
    // Application context, so we can call other methods as we need to throughout.

    // Please note, this code actually has potential memory leaks, because our
    // AsyncTask could live longer than the Activity (or application) does and will
    // therefore hold onto the reference long after it should. I am going to leave this code
    // as is here, so as to not cloud the other components of the AsyncTask. Then,
    // please see the LoadFileTask for the correct way to do it using WeakReferences.
    private Context context; // This should actually be a WeakReference<Context>
    private ProgressBar progressBar; // This should actually be a WeakReference<ProgressBar>

    public CreateFileTask(Context context, ProgressBar progressBar) {
        // When the task is created, we will pass in the context, and
        // the progress bar to be used later.
        this.context = context;
        this.progressBar = progressBar;
    }

    @Override
    protected void onPreExecute() {
        // This method will be call first thing on the main UI thread, so we
        // can do any initial setup items here.

        // Reset the progress bar to 0
        progressBar.setProgress(0);

        Toast.makeText(context, "Creating file.", Toast.LENGTH_SHORT).show();
    }

    @Override
    protected Void doInBackground(String... file) {
        // This method will be run on a background thread for us.

        // The weird "String..." type says that that there could potentially be
        // more than String string. It is called a Variable Length argument,
        // and just simplifies the syntax so we don't have to create an array
        // and put one thing into it, when we call the function.

        String filename = file[0];

        try (FileOutputStream outputStream = context.openFileOutput(filename, Context.MODE_PRIVATE)) {

            for (int i = 1; i <= 10; i++) {
                // Write the number to the file
                String line = String.format("%d%n", i);
                outputStream.write(line.getBytes());

                // This line is very important. It will pass this integer value
                // to our onProgressUpdate function below. The reason we need to
                // do this, instead of just updating the progress bar directly
                // is that we can't update the progressBar from a backgroundThread
                // (which is where this method is running). Instead, we give the
                // information to another method which will be run on the main
                // UI thread for us instead.
                publishProgress(i * 10);

                // Simulate a more difficult task by sleeping for 1/4 second
                Thread.sleep(250);
            }
        } catch (FileNotFoundException e) {
            // We should really do something much better than printing
            // the stack track here, because it will just get lost in our
            // StandardOut, and no one will ever go looking for it.

            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        // We need to return null, because technically our return type is:
        // "Void" (capital V) not "void", which is an object type. The same
        // idea as using Integer instead of int.
        return null;
    }

    @Override
    protected void onProgressUpdate(Integer... data) {
        // This method will be invoked on the main UI thread so we can
        // manipulate Views like the progress bar.

        progressBar.setProgress(data[0]);
    }

    @Override
    protected void onPostExecute(Void result) {
        // This method will be invoked on the main UI thread when the whole
        // process is finished.

        // Inform the user that the task is complete
        Toast.makeText(context, "Finished Saving", Toast.LENGTH_SHORT).show();
    }

}
