package edu.byui.cs.teamactivity06asynctask;

import android.content.Context;
import android.os.AsyncTask;
import android.widget.ArrayAdapter;
import android.widget.ProgressBar;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.lang.ref.WeakReference;

/**
 * Created by sburton on 2/14/18.
 */


// This class is very similar to the CreateFileTask.
// **** Please read the comments for the CreateFileTask first! *****

public class LoadFileTask extends AsyncTask<String, Integer, Void > {

    // This time, we are going to do this the correct way, and not have
    // memory leaks. To do so, we will not store the context itself, but instead
    // store WeakReferences to it. That way, if the context goes away, this
    // class will not make it stay in memory.

    private WeakReference<Context> contextReference;
    private WeakReference<ProgressBar> progressBarReference;
    private WeakReference<ArrayAdapter<Integer>> arrayAdapterReference;

    public LoadFileTask(Context context, ProgressBar progressBar, ArrayAdapter<Integer> arrayAdapter) {
        this.contextReference = new WeakReference<>(context);
        this.progressBarReference = new WeakReference<>(progressBar);
        this.arrayAdapterReference = new WeakReference<>(arrayAdapter);
    }

    @Override
    protected void onPreExecute() {
        // Because we only have a weak reference to the progress bar, we can't
        // be sure that it is still around, so we need to check if it's null first
        ProgressBar progressBar = progressBarReference.get();

        if (progressBar != null) {
            // Reset the progress bar
            progressBar.setProgress(0);
        }

        // Similarly, with the context reference:
        Context context = contextReference.get();

        if (context != null) {
            Toast.makeText(context, "Loading file.", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    protected Void doInBackground(String... file) {
        String filename = file[0];

        // Again, we must verify that the context is still around:
        Context context = contextReference.get();

        if (context != null) {

            try (FileInputStream inputStream = context.openFileInput(filename)) {
                try (BufferedReader reader = new BufferedReader(new InputStreamReader(inputStream))) {

                    // Read the file, line by line
                    String line;
                    while ((line = reader.readLine()) != null) {

                        // Get the number out of the file
                        int i = Integer.parseInt(line);

                        publishProgress(i);

                        // Simulate a more difficult task by sleeping for 1/4 second
                        Thread.sleep(250);
                    }
                }

            } catch (IOException e) {
                e.printStackTrace();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }

        return null;
    }


    @Override
    protected void onProgressUpdate(Integer... data) {
        // First verify that our objects are still around
        ArrayAdapter<Integer> arrayAdapter = arrayAdapterReference.get();
        ProgressBar progressBar = progressBarReference.get();

        if (arrayAdapter != null && progressBar != null) {

            Integer i = data[0];

            // Put the number in the adapter, which is connected to the ListView
            arrayAdapter.add(i);

            // See how many things are in the adapter, and update the ProgressBar
            int adapterCount = arrayAdapter.getCount();
            progressBar.setProgress(adapterCount * 10);
        }
    }

    @Override
    protected void onPostExecute(Void result) {
        // Again, we must verify that the context is still around:
        Context context = contextReference.get();

        if (context != null) {
            // Inform the user that the task is complete
            Toast.makeText(context, "Finished Loading", Toast.LENGTH_SHORT).show();
        }
    }

}
